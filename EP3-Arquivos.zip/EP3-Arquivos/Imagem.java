class Imagem
{
  int[][] pixels;
  
  // Inicializa matriz de pixels da classe
  Imagem(int[][] matriz)
  {
    pixels = matriz;
  }
  
  // Devolve largura em pixels da imagem
  int largura()
  {
    if (pixels != null)
      return pixels[0].length;
    else
      return 0;
  }
  
  // Devolve altura em pixels da imagem
  int altura()
  {
    if (pixels != null)
      return pixels.length;
    else
      return 0;
  }
  
  // Suaviza imagem com filtro m�dio
  void filtroMedio(int tamanho)
  {
    // Para voc� completar!
  }
  
  // Suaviza imagem com filtro mediano
  void filtroMediano(int tamanho)
  {
    // Para voc� completar!
  }
  
  // Suaviza imagem com filtro gaussiano
  void filtroGaussiano(double sigma, int tamanho)
  {
    // Para voc� completar!
  }
  
}