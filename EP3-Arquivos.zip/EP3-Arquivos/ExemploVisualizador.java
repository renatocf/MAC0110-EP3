class ExemploVisualizador
{
  public static void main(String[] args)
  {
    // Cria inst�ncia do visualizador
    VisualizadorImagem vis = new VisualizadorImagem();
    
    // L� imagem
    Imagem barbara = LeituraEscritaImagem.leImagem("Barbara.pgm");
    
    // Mostra imagem 
    vis.mostraImagem(barbara, "Barbara.pgm");
    
    // Escreve imagem
    LeituraEscritaImagem.escreveImagem("Barbara_copia.pgm", barbara);
  }
}