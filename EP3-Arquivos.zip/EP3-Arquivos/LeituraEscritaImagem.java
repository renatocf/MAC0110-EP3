import java.io.*;
import java.io.ByteArrayInputStream;
import java.util.*;

class LeituraEscritaImagem
{
  // L� valor inteiro de arquivo
  // N�o muito eficiente, por�m funcional para pgms
  static private int leProximoInt(FileInputStream fis)
  {
    try { 
      int valor = 0;
      String token = "";
      while (valor <= ' ')
        valor = fis.read();
      while (valor > ' ') {
        token = token + (char)valor;
        valor = (char)fis.read();
      }
      Scanner sc1 = new Scanner(token);
      return sc1.nextInt();
    } catch (IOException e) {
      e.printStackTrace();
      return -1;
    }
  }
  
  // L� uma imagem no format pgm
  public static Imagem leImagem(String nome)
  { 
    try { 
      FileInputStream pgm = new FileInputStream(nome);
      
      // Abre arquivo com o nome especificado para leitura
      byte[] magic_array = new byte[2];
      magic_array[0] = (byte)pgm.read();
      magic_array[1] = (byte)pgm.read();
      
      // L� n�mero m�gico que identifica formato do arquivo.
      // Um arquivo pgm possui a string "P5" como n�mero m�gico
      String magic = new String(magic_array);
      if (!magic.equals("P5"))
      {
        System.err.println(nome + " n�o est� no formato pgm.");
        return null;
      }
      
      // L� largura da imagem em pixels 
      int largura = leProximoInt(pgm);
      
      // L� altura da imagem em pixels
      int altura = leProximoInt(pgm);
      
      // L� valor m�ximo para os pixels deste arquivo
      int valmax = leProximoInt(pgm);
      
      // Caso intensidade m�xima seja maior que 255,
      // pixels s�o compostos de 2 bytes e n�o
      // daremos suporte a esta varia��o.
      if (valmax > 255)
      {
        System.err.println(nome + " est� em um formato pgm n�o suportado.");
        return null;
      }
      
      // L� matriz de pixels
      int[][] pixels = new int[altura][largura];
      for(int i=0;i<altura;i++)
        for(int j=0;j<largura;j++) {
           pixels[i][j] = pgm.read();
      }
      
      // Fecha arquivo
      pgm.close();
      
      // Devolve um objeto imagem
      return new Imagem(pixels);
      
    } catch (FileNotFoundException e) {
    } catch (IOException e) {
      e.printStackTrace();
    }
    
    return null;
  }
  
  public static void escreveImagem(String nome, Imagem imagem)
  {
    if (imagem.pixels == null)
    {
      System.err.println("Imagem n�o cont�m pixels para escrever.");
      return;
    }
    
    try { 
      
      // Abre arquivo para grava��o
      FileOutputStream pgm = new FileOutputStream(nome);
            
      // Escreve n�mero m�gico
      pgm.write('P');
      pgm.write('5');
      pgm.write(10);
      
      // Escreve largura e altura da imagem    
      int largura = imagem.pixels[0].length;
      int altura = imagem.pixels.length;
      
      String tamanho = Integer.toString(largura) 
        + " " + Integer.toString(altura);                                
      byte[] array = tamanho.getBytes();      
      for(int i=0;i<array.length;i++)
        pgm.write(array[i]);
      pgm.write(10);
      
      // Escreve valor maximo para pixels
      pgm.write('2');
      pgm.write('5');
      pgm.write('5');
      pgm.write(10);
        
      // Escreve pixels
      for(int i=0;i<altura;i++)
        for(int j=0;j<largura;j++)
           pgm.write(imagem.pixels[i][j]);
      
      // Fecha arquivo
      pgm.close();
      
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}